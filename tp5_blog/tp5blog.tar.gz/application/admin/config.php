<?php
//后台配置文件
return [
    // 视图输出字符串内容替换
    'view_replace_str'       => [
        '__ADMIN__' => '/public/static/admin',
        '__STATIC__'=> '/public/static'
    ],

];