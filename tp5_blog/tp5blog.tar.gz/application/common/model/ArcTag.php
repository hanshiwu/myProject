<?php

namespace app\common\model;

use think\Model;

class ArcTag extends Model
{
    protected $table = 'blog_arc_tag';
}
