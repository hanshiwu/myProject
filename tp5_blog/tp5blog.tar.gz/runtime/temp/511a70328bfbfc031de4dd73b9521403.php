<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"/data/home/hyu3352580001/htdocs/application/admin/view/login/login.html";i:1513560032;}*/ ?>
<!DOCTYPE html>
<html lang="en" class="bg-dark">
<head>
    <meta charset="utf-8"/>
    <title>博客网后台登陆</title>
    <meta name="description"content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <link href="__ADMIN__/bootstrap-3.3.0-dist/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="__ADMIN__/admin.ui/css/animate.css" type="text/css"/>
    <link rel="stylesheet" href="__ADMIN__/admin.ui/css/app.css" type="text/css"/>
    <!--[if lt IE 9]>
    <script src="__ADMIN__/admin.ui/js/ie/html5shiv.js"></script>
    <script src="__ADMIN__/admin.ui/js/ie/respond.min.js"></script>
    <script src="__ADMIN__/admin.ui/js/ie/excanvas.js"></script>
    <![endif]-->
</head>
<body class="">
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
    <div class="container aside-xxl">
        <a class="navbar-brand block" href="">博客网后台管理</a>
        <section class="panel panel-default bg-white m-t-lg">
            <header class="panel-heading text-center">
                <strong>管理员后台登陆</strong>
            </header>
            <form method="post" action="<?php echo url('login/login'); ?>" class="panel-body wrapper-lg">
                <div class="form-group">
                    <label class="control-label">用户名</label>
                    <input  type="text" class="form-control input-lg" name="username">
                </div>
                <div class="form-group">
                    <label class="control-label">密 码</label>
                    <input  type="password"  class="form-control input-lg" name="pwd">
                </div>
                <div class="form-group">
                    <label class="control-label">验证码</label>
                    <input type="text"  class="form-control input-lg col-md-6" name="code">
                    <img src="<?php echo captcha_src(); ?>" onclick="this.src=this.src+'?'+Math.random()">
                </div>
                <button type="submit" class="btn btn-primary">登陆后台</button>
            </form>
        </section>
    </div>
</section>
<!-- footer -->

<script src="__ADMIN__/admin.ui/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="__ADMIN__/admin.ui/js/bootstrap.js"></script>
<!-- App -->
<script src="__ADMIN__/admin.ui/js/app.js"></script>
<script src="__ADMIN__/admin.ui/js/app.plugin.js"></script>
</body>
</html>