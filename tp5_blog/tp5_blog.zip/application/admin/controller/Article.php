<?php

namespace app\admin\controller;

use think\Controller;

class Article extends Controller
{
    public function index(){
        return $this->fetch();
    }
    public function add(){
        /*获取分类数据*/
        $cate = new \app\common\model\Category();
        $cateData = $cate->getAll();
        $this->assign('cateData',$cateData);
        /*获取标签数据*/
        $tagData = db('tag')->select();
        $this->assign('tagData',$tagData);
        return $this->fetch();
    }
}
